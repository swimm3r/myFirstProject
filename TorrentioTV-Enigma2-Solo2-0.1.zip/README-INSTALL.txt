TorrentioTV Enigma2 - VU+ Solo2 (prototype 0.1)

INSTALARE
1. Extrage arhiva pe calculator.
2. Copiaza folderul TorrentioTV in:
   /usr/lib/enigma2/python/Plugins/Extensions/
   Rezultatul trebuie sa fie:
   /usr/lib/enigma2/python/Plugins/Extensions/TorrentioTV/plugin.py
3. Repornește Enigma2 (nu este necesară repornirea receptorului).
4. Din meniul Plugins deschide TorrentioTV.
5. Configurează URL-ul Gateway-ului existent, de exemplu:
   http://192.168.1.X:4000
6. Alege Check Gateway / Worker.

IMPORTANT
- Aceasta este doar o versiune de diagnostic: verifică legătura cu Gateway/Worker.
- Nu pornește torrente și nu redă video.
- Nu instala Node.js, WebTorrent sau alt motor pe receptor.
- Kodi și Enigma2 rămân clienți alternativi: nu le folosi simultan pe aceeași sesiune.
- Compatibilitatea cu imaginea BlackHole trebuie confirmată pe receptor.
